//
//  ViewController.m
//  HomeWork Lesson 22 (Touches.Simple Drag and Drop)
//
//  Created by Anton Gorlov on 25.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) UIView* draggingView;
@property (assign, nonatomic) CGPoint touchOffset;
@property (strong, nonatomic) NSMutableArray* arrayChecker;
@property (strong, nonatomic) NSMutableArray* arrayBlackCells;
@property (strong, nonatomic) NSMutableArray* arrayFreeCells;
@end

@implementation ViewController

/* Уровень супермен (остальных уровней не будет)
 
 1. Создайте шахматное поле (8х8), используйте черные сабвьюхи
 2. Добавьте балые и красные шашки на черные клетки (используйте начальное расположение в шашках)
 3. Реализуйте механизм драг'н'дроп подобно тому, что я сделал в примере, но с условиями:
 4. Шашки должны ставать в центр черных клеток.
 5. Даже если я отпустил шашку над центром белой клетки - она должна переместиться в центр ближайшей к отпусканию черной клетки.
 6. Шашки не могут становиться друг на друга
 7. Шашки не могут быть поставлены за пределы поля.
 
 Вот такое вот веселое практическое задание :)
*/

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.arrayChecker = [[NSMutableArray alloc]init];
    self.arrayBlackCells = [[NSMutableArray alloc]init];
    self.arrayFreeCells =[[NSMutableArray alloc]init];

   
    for (int x = 0; x < 8; x++) {
        
        for (int y = 0; y < 8; y++) {
            UIView* view = [[UIView alloc] initWithFrame:CGRectMake(x*50, y*50+20, 50, 50)];//доска
            
            view.layer.borderWidth = 0.9f;//полоса между клеточками
            view.layer.borderColor = [UIColor grayColor].CGColor;
            view.backgroundColor = ((x+y) %2) == 0 ? [UIColor whiteColor] : [UIColor blackColor];
            
            if ([view.backgroundColor isEqual:[UIColor blackColor]]) {
                [self.arrayBlackCells addObject:view];
                if (y == 3 | y == 4) {
                    [self.arrayFreeCells addObject:[NSValue valueWithCGPoint:view.center]];
                }
                
            }
            if ([view.backgroundColor isEqual:[UIColor blackColor]] && y!=3 && y!=4) { //3 на 4 доска
                UIView* viewCheck = [[UIView alloc] initWithFrame:CGRectMake(view.frame.origin.x+5,view.frame.origin.y+5,40,40)];// рисуем шашки
                
                viewCheck.tag = 2;
                viewCheck.layer.borderWidth = 2.9f; //обод у шашки (оконтовка)
                viewCheck.layer.borderColor = [UIColor grayColor].CGColor;
                viewCheck.layer.cornerRadius = 20; // округленность
                
                if (y<3) {
                    viewCheck.backgroundColor = [UIColor redColor]; // цвета шашек
                }
                if (y>4) {
                    viewCheck.backgroundColor = [UIColor whiteColor];
                }
                
                
                [self.arrayChecker addObject:viewCheck];
                [self.view addSubview:viewCheck]; // выставляем шашки на доску
                
            }
            
                [self.view addSubview:view]; // доска
                [self.view sendSubviewToBack:view];
        }
    }
    
    //self.view.multipleTouchEnabled = YES;
}


-(UIInterfaceOrientationMask) supportedInterfaceOrientation {
    
    return UIInterfaceOrientationMaskAll;
    
}

#pragma mark - Privite method

- (CGFloat) getDistanceBetween: (CGPoint) first and: (CGPoint) second
{
    CGFloat x = (second.x - first.x);
    CGFloat y = (second.y - first.y);
    
    return sqrt((x*x) + (y*y));
    
}
- (void) onTouchesEnded {
    [UIView animateWithDuration:0.3 animations:^{
        self.draggingView.transform = CGAffineTransformIdentity;
        self.draggingView.alpha = 1.f;
    }];
    self.draggingView = nil;
}

- (void) logTouches:(NSSet<UITouch *> *)touches withMethod:(NSString *) methodName {//метод,которые информирует о : 1)Начале касания. 2)Движении. 3)Завершении касания. 4)Отмене касания.
    
    NSMutableString* string = [NSMutableString stringWithString:methodName];
    
    for (UITouch* touch in touches) {
        CGPoint point = [touch locationInView:self.view];
        [string appendFormat:@" %@", NSStringFromCGPoint(point)];
    }
    NSLog(@"%@", string);
}

#pragma mark - Touches

- (void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    [self logTouches:touches withMethod:@"touchesBegan"];
    
    UITouch* touch = [touches anyObject];
    
    CGPoint pointOnMainView = [touch locationInView:self.view];
    
    UIView* view = [self.view hitTest:pointOnMainView withEvent:event];// где было сделано касание
    
    if (view.tag == 2) {
        
        self.draggingView = view;
        
        [self.view bringSubviewToFront:self.draggingView]; // view на передний план
        
        CGPoint touchPoint = [touch locationInView:self.draggingView]; // где сделано касание
        
        self.touchOffset = CGPointMake(CGRectGetMidX(self.draggingView.bounds) - touchPoint.x, CGRectGetMidY(self.draggingView.bounds) - touchPoint.y); // определяем точку смещения
        
        [UIView animateWithDuration:0.3 animations:^{
            
            self.draggingView.transform = CGAffineTransformMakeScale(1.3f, 1.3f);
            self.draggingView.alpha = 0.5f;
            
        }];
    } else {
        self.draggingView = nil;
    }
    [self.arrayFreeCells addObject:[NSValue valueWithCGPoint:self.draggingView.center]]; //ставим шашку по центру клетки
    
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
   
    if (self.draggingView) {
        
        UITouch* touch = [touches anyObject];
        CGPoint pointOnMainView = [touch locationInView:self.view];
        CGPoint correction = CGPointMake(pointOnMainView.x + self.touchOffset.x, pointOnMainView.y+self.touchOffset.y);
        self.draggingView.center = correction;
        
    }
  
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
    
    if (self.draggingView) {
        UITouch* touch = [touches anyObject];
        CGPoint pointOnBoard = [touch locationInView:self.view];
        
        CGFloat minDistance = MAXFLOAT;
        CGPoint cellWithMinDistance = CGPointZero;
        
        
        for (NSValue* cells in self.arrayFreeCells) {//ставим шашки в ближайшую свободную клетку 
            
            
            CGPoint cellPoint = [cells CGPointValue];
            
            
            CGFloat getCellWithMinDistance = [self getDistanceBetween:cellPoint and:pointOnBoard];
            
            if (getCellWithMinDistance < minDistance)
            {
                minDistance = getCellWithMinDistance;
                cellWithMinDistance = cellPoint;
            }
            
            CGPoint correction = CGPointMake(cellWithMinDistance.x, cellWithMinDistance.y);
            self.draggingView.center = correction;
            
        }
    }
    
    [self.arrayFreeCells removeObject:[NSValue valueWithCGPoint:self.draggingView.center]];
    [self onTouchesEnded];
    

    
}


- (void)touchesCancelled:(nullable NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{

     [self logTouches:touches withMethod:@"touchesCancelled"];
       [self onTouchesEnded];
}

@end
