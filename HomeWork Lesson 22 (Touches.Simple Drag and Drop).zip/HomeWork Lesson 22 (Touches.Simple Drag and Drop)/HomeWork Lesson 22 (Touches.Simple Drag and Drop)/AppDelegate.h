//
//  AppDelegate.h
//  HomeWork Lesson 22 (Touches.Simple Drag and Drop)
//
//  Created by Anton Gorlov on 25.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

