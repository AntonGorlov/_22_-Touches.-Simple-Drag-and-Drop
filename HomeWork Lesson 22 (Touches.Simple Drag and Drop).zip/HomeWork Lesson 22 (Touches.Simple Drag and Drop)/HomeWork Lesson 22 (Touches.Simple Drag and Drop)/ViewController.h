//
//  ViewController.h
//  HomeWork Lesson 22 (Touches.Simple Drag and Drop)
//
//  Created by Anton Gorlov on 25.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
/*
@property (weak, nonatomic) IBOutlet UIView* chessBoard;

@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *whiteCells;

@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *blackCells;

@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *redCheckers;

@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *greenCheckers;
*/





@end

